
console.log("Dukandari MVP loaded successfully!");
